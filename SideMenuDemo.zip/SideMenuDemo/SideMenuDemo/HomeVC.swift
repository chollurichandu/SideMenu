//
//  HomeVC.swift
//  SideMenuDemo
//
//  Created by Balasubramanian on 27/11/18.
//  Copyright © 2018 Balasubramanian. All rights reserved.
//

////https://github.com/sumitjagdev/SJSwiftSideMenuController
import UIKit
import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if let image : UIImage = UIImage(named: "menu") as UIImage? {
            SJSwiftSideMenuController .showLeftMenuNavigationBarButton(image: image)
            //SJSwiftSideMenuController .showRightMenuNavigationBarButton(image: image)
        }
        
        SJSwiftSideMenuController.enableDimbackground = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    

}
