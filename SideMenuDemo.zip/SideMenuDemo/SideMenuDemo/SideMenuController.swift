//
//  SideMenuController.swift
//  SJSwiftNavigationController
//
//  Created by Mac on 12/19/16.
//  Copyright © 2016 Sumit Jagdev. All rights reserved.
//

import UIKit


class SideMenuController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var menuTableView : UITableView!
   
    var menuItems : NSArray = NSArray()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
       // menuTableView.bounces = false

       
        menuItems = ["Home","VC1","VC2","VC3","Logout"]
        
        menuTableView.cellLayoutMarginsFollowReadableWidth = false
        
        menuTableView.separatorInset = UIEdgeInsets.zero
        
        // tableView - hiding the empty rows
        self.menuTableView.tableFooterView = UIView(frame: .zero)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        menuTableView.allowsSelection = true
        menuTableView.isUserInteractionEnabled = true
        self.view.backgroundColor = UIColor.clear
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let idstr = "cell"
        
        var cell : UITableViewCell! = tableView.dequeueReusableCell(withIdentifier: idstr)!
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: idstr)
        }
        let menuName = menuItems.object(at: indexPath.row) as? String
        cell.textLabel?.text = menuName
        
        
        cell.layer.borderColor = UIColor.gray.cgColor
        
        cell.layoutMargins = UIEdgeInsets.zero
        
        //UITableViewCell: rounded corners and shadow
        let layer = cell.layer
        layer.shadowOffset = CGSize(width: 0, height: 1)
        layer.shadowRadius = 2
        layer.shadowColor = UIColor.lightGray.cgColor
        layer.shadowOpacity = 0.2
        layer.frame = cell.frame
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
      
         let menuName = menuItems.object(at: indexPath.row) as? String
        
        if indexPath.row == 0{
            let destVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
            destVC.title = menuName
            SJSwiftSideMenuController.pushViewController(destVC, animated: true)
        }
        if indexPath.row == 1{
            let destVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VC1") as! VC1
            destVC.title = menuName
            SJSwiftSideMenuController.pushViewController(destVC, animated: true)
        }

        if indexPath.row == 2{
            let destVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VC2") as! VC2
            destVC.title = menuName
            SJSwiftSideMenuController.pushViewController(destVC, animated: true)
        }
        if indexPath.row == 3{
            let destVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VC3") as! VC3
            destVC.title = menuName
            SJSwiftSideMenuController.pushViewController(destVC, animated: true)
        }
        if indexPath.row == 4{
            
            
            let refreshAlert = UIAlertController(title: "Logout", message: "Are you sure you want to log out?", preferredStyle: UIAlertControllerStyle.alert)
            
            refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                
                UserDefaults.standard.set(false, forKey: "isUserLoggedIn")
                UserDefaults.standard.synchronize()
                
                let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC

                let appDel:AppDelegate = UIApplication.shared.delegate as! AppDelegate

                appDel.window?.rootViewController = loginVC
                
               
                
                
            }))
            
            refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                print("Handle Cancel Logic here")
                
                
                
            }))
            
            present(refreshAlert, animated: true, completion: nil)
        }

       
        
        SJSwiftSideMenuController.hideLeftMenu()
      
        
    }
   
}
extension CGFloat {
    public static func random() -> CGFloat {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
}
extension UIColor {
    public static func randomColor() -> UIColor {
        // If you wanted a random alpha, just create another
        // random number for that too.
        return UIColor(red:   .random(),
                       green: .random(),
                       blue:  .random(),
                       alpha: 1.0)
    }
}

