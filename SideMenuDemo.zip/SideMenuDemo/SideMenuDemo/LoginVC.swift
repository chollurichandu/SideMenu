//
//  LoginVC.swift
//  SideMenuDemo
//
//  Created by Balasubramanian on 27/11/18.
//  Copyright © 2018 Balasubramanian. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet var tfUserName: UITextField!
    
    @IBOutlet var tfPassword: UITextField!
    
    
    @IBOutlet var btnLogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //SnapKit Constrainits
        
        tfUserName.snp.makeConstraints { (make) in
           
           // make.leftMargin.equalTo(10)
           // make.topMargin.equalTo(100)
           // make.centerX.equalTo(self.view.frame.width/2)
            
        }
        tfPassword.snp.makeConstraints { (make) in
            
           
            
        }
        
        btnLogin.snp.makeConstraints { (make) in
            
         
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnLoginAction(_ sender: Any) {
        
        
        UserDefaults.standard.set(true, forKey: "isUserLoggedIn")
        
        UserDefaults.standard.synchronize()
        
        DispatchQueue.main.async {
            
            AppDelegate.sharedInstance().window? = UIWindow(frame: UIScreen.main.bounds)
            
            
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let mainVC = SJSwiftSideMenuController()
            let sideVC_L : SideMenuController = (storyBoard.instantiateViewController(withIdentifier: "SideMenuController") as? SideMenuController)!
            
            let sideVC_R : SideMenuController = (storyBoard.instantiateViewController(withIdentifier: "SideMenuController") as? SideMenuController)!
            
            let rootVC = storyBoard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
            
            SJSwiftSideMenuController.setUpNavigation(rootController: rootVC, leftMenuController: sideVC_L, rightMenuController: sideVC_R, leftMenuType: .SlideOver, rightMenuType: .SlideView)
            
            SJSwiftSideMenuController.enableSwipeGestureWithMenuSide(menuSide: .LEFT)
            
            SJSwiftSideMenuController.enableDimbackground = true
            SJSwiftSideMenuController.leftMenuWidth = 280
            
            
            AppDelegate.sharedInstance().window?.rootViewController = mainVC
            AppDelegate.sharedInstance().window?.makeKeyAndVisible()

        }
        
    }
    
}

