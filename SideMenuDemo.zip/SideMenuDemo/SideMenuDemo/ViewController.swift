//
//  ViewController.swift
//  SideMenuDemo
//
//  Created by Balasubramanian on 26/11/18.
//  Copyright © 2018 Balasubramanian. All rights reserved.
//


//https://github.com/sumitjagdev/SJSwiftSideMenuController

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        Timer.scheduledTimer(timeInterval:1, target: self, selector: #selector(self.splashTimeOut(sender:)), userInfo: nil, repeats: false)
     
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- splashTimeOut
    
    @objc func splashTimeOut(sender : Timer){
        
        let userLoginStatus = UserDefaults.standard.bool(forKey: "isUserLoggedIn")
        
        print("\n userLoginStatus :\(userLoginStatus)")
        
        
        
        
        if userLoginStatus == false{
            
             self.performSegue(withIdentifier:"LoginVC", sender:self)
            
            
        }
        else{
            
            AppDelegate.sharedInstance().window? = UIWindow(frame: UIScreen.main.bounds)


            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let mainVC = SJSwiftSideMenuController()
            let sideVC_L : SideMenuController = (storyBoard.instantiateViewController(withIdentifier: "SideMenuController") as? SideMenuController)!
            
            let sideVC_R : SideMenuController = (storyBoard.instantiateViewController(withIdentifier: "SideMenuController") as? SideMenuController)!
          
            let rootVC = storyBoard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
            
            SJSwiftSideMenuController.setUpNavigation(rootController: rootVC, leftMenuController: sideVC_L, rightMenuController: sideVC_R, leftMenuType: .SlideOver, rightMenuType: .SlideView)
            
            SJSwiftSideMenuController.enableSwipeGestureWithMenuSide(menuSide: .LEFT)
            
            SJSwiftSideMenuController.enableDimbackground = true
            SJSwiftSideMenuController.leftMenuWidth = 280
           
            
            AppDelegate.sharedInstance().window?.rootViewController = mainVC
            AppDelegate.sharedInstance().window?.makeKeyAndVisible()
            
        }
        
        
        
        
        
    }


}

